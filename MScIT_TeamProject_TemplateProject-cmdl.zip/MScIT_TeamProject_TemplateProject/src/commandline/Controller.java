package commandline;

import java.util.Scanner;

public class Controller {

	GameTable gt;
	MessageCenter mc;
	Scanner s;
	
	
	public Controller(GameTable gt, MessageCenter mc) {
		this.gt = gt;
		this.mc = mc;
		s = new Scanner(System.in);
	}
	
	public void addPlayer(Player p) {
		gt.addPlayer(p);
	}
	
	public void Play () {
		gt.initialization();
		mc.startInfo();
		int input = s.nextInt();
		s.nextLine();
		if(input == 2) {
			roundPlay();
		}
	}
	
	public void roundPlay() {
		while(!gt.getIsOver()) {
			gt.addGameRound();
			mc.roundMassage();
			gt.selectAttribute();
			mc.selectedAttribute();
			gt.comparison(gt.getBanker());
			mc.winnerMessage(gt.getRoundWinner().getTopmostCard(),gt.getRoundWinner());
			gt.cardChange();
			gt.playerCheck();
			mc.bankerChangeMessage(gt.bankerChange());
			mc.livingPlayers();
			if(gt.getIsOver()) {
				mc.gameOver();
			}
		}
	}
	

}
