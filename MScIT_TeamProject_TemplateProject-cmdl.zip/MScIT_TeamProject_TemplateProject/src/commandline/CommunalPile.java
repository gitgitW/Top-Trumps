package commandline;

public class CommunalPile extends Deck{
	
	public CommunalPile(GameTable gt) {
		super(gt);
	}
	
	public void clearPile () {
		super.cards.clear();
	}

	
}
