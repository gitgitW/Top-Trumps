package commandline;

import java.util.HashMap;

public class Card {
	
	private String name;
	private int attribute1,attribute2,attribute3,attribute4,attribute5;
	private HashMap<String,Integer> attribute;
	private int[] attributes;
	private String[] attributesName;
	
	public Card(String name, int attribute1, int attribute2, int attribute3, int attribute4, int attribute5) {
		
		this.name = name;
		attributes = new int[5];
		attributesName = new String[5];
		attribute = new HashMap<String,Integer>();
		
		attributesName[0] = "height";
		attributesName[1] = "weight";
		attributesName[2] = "length";
		attributesName[3] = "ferocity";
		attributesName[4] = "intelligence";
		
		attribute.put("attribute1", attribute1);
		attribute.put("attribute2", attribute2);
		attribute.put("attribute3", attribute3);
		attribute.put("attribute4", attribute4);
		attribute.put("attribute5", attribute5);
		
		this.attribute1 = attribute1; attributes[0] = this.attribute1;
		this.attribute2 = attribute2; attributes[1] = this.attribute2;
		this.attribute3 = attribute3; attributes[2] = this.attribute3;
		this.attribute4 = attribute4; attributes[3] = this.attribute4;
		this.attribute5 = attribute5; attributes[4] = this.attribute5;
		
	}
	
	public String[] getAttributesName() {
		return attributesName;
	}
	
	public String getSelectedAttribute(int index) {
		return attributesName[index];
	}
	
	public String getName () {
		return this.name;
	}
	
	public int[] getAttributes () {
		return this.attributes;
	}
	
	public int selectAttribute(int index) {
		switch (index) {
		case 0 : return attributes[0];
		case 1 : return attributes[1];
		case 2 : return attributes[2];
		case 3 : return attributes[3];
		case 4 : return attributes[4];
		}
		return 0;
	}
	
	public int comparison (Card card, int index) {
		if(card.getAttributes()[index] > this.attributes[index]) {
			return -1;
		}
		else if (card.getAttributes()[index] < this.attributes[index]) {
			return 1;
		}
		else return 0;

	} 

}
