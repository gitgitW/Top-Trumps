package commandline;

import java.util.HashMap;
import java.util.Scanner;

public class GameTable {

	private int playerNum;
	private Player[] players;
	private Deck deck;
	private int gameRound;
	private boolean isOver;
	private int selectedAttribute;
	private Player banker;
	private CommunalPile communalPile;
	private boolean isDrew;
	private Player roundWinner;
	private HashMap<Integer,Player> playersOnTable; 
	private int livingPlayer;
	private Card winningCard;
	private Scanner s;
	
	public GameTable (int playerNum) {
		
		this.playerNum = playerNum;
		this.players = new Player[playerNum];
		this.playerNum = 0;
		this.s = new Scanner(System.in);
		this.playersOnTable = new HashMap<Integer,Player>();
		communalPile = new CommunalPile(this);
		deck = new Deck(this);

		isOver = false;
		isDrew = false;
		
		gameRound = 0;

	}
	

	
	public void initialization() {
		banker = players[0];
	}
	
	public void addPlayer(Player player) {
		players[playerNum] = player;
		playersOnTable.put(++playerNum, player);
		player.setPlayerNum(playerNum);
	}
	
	public boolean bankerChange() {
		
		//comparison and compare the condition what wather the Banker should be changed
		//System.out.println("Try to change banker");
		if (!banker.getName().equals(roundWinner.getName())) {
			//System.out.println("banker Changed");
			int fixedI;
			for(int i = banker.getPlayerNum(); i < banker.getPlayerNum() + playerNum - 1; i++) {
				
				if(i > playerNum - 1) {
				   fixedI = i - (playerNum);
				}
				else fixedI = i;

				if(players[fixedI].getIsOver() != -1) {
				    banker = players[fixedI];
				    return true;
				}
			}
		}
		return false;
		

	}
	
	public void cardChange() {

		if(isDrew == true) {
			drew();
		}
		
		else {
			//System.out.println("Try to change cards");
			for(int i = 0; i < playerNum; i++) {
				if(players[i].getIsOver() == 0) {
				roundWinner.addCard(players[i].getTopmostCard());
				players[i].removeTopmostCard();
				//System.out.println(players[i].getName()+" remove cards, cards num: " + players[i].getCardNum());
				}
			}

		}

	}
	
	public void playerCheck() {
		livingPlayer = playerNum;
		for(int i = 0; i < playerNum; i++) {
			players[i].selfCheck();
			livingPlayer += players[i].getIsOver();
		}
		
		if(livingPlayer == 1||players[0].getIsOver() == -1) {
			gameOver();
		}
	}
	
	public void addGameRound() {
		gameRound++;
	}
	

	public Player comparison(Player banker) {
	    roundWinner = banker;
		isDrew = false;
		//System.out.println("comparison......., banker:" + banker.getName());
		int fixedI;
		for(int i = banker.getPlayerNum(); i < banker.getPlayerNum() + playerNum - 1; i++) {

			if(i > playerNum - 1) {
			   fixedI = i - (playerNum);
			}
			else fixedI = i;
			//System.out.println(fixedI);
			if(players[fixedI].getIsOver() == 0) {
			if (roundWinner.getTopmostCard().comparison(players[fixedI].getTopmostCard(), selectedAttribute) == 1) {
				isDrew = false;
			}
			else if (roundWinner.getTopmostCard().comparison(players[fixedI].getTopmostCard(), selectedAttribute) == 0) {
				isDrew = true;
			}
			else if (roundWinner.getTopmostCard().comparison(players[fixedI].getTopmostCard(), selectedAttribute) == -1) {
				roundWinner = players[fixedI];
				isDrew = false;
			}
			}
		}
		//System.out.println("is drew: " + isDrew);
		winningCard = roundWinner.getTopmostCard();
		return roundWinner;
	}
	
	public Player getBanker() {
		return banker;
	}
	
	public void drew() {
		System.out.println("this is a drew");
//		communalPile.clearPile();
//		for (int i = 0; i < players.length; i++) {
//			if(players[i].getIsOver() == 0) {
//			communalPile.cards.add(players[i].getTopmostCard());
//			players[i].removeTopmostCard();
//			}
//		}
	}
	
	public void selectAttribute() {
		if(banker.getIsBot() == true) {
			banker.AIPlay();
		}
		else {
			int index = s.nextInt();
			s.nextLine();
			banker.Play(index - 1);
		}
		selectedAttribute = banker.getSelectedAttribute();
	}
	
	public void gameOver() {
		isOver = true;
	}
	
	public boolean getIsOver() {
		return isOver;
	}
	public Deck getDeck() {
		return deck;
	}
	
	public int getGameRound() {
		return gameRound;
	}
	
	public Player[] getPlayers() {
		return players;
	}
	
	public int getPlayerNum() {
		return playerNum;
	}
	
	public Player getRoundWinner() {
		return roundWinner;
    }
	
	public int getLivingPlayerNum() {
		return livingPlayer;
	}
	
	public Player getHumanPlayer() {
		for(int i = 0; i < players.length; i++) {
			if(players[i].getIsBot() == false) {
				return players[i];
			}
		}
		return players[0];
	}
	
	public int getSelectedAttribute() {
		return selectedAttribute;
	}
}
//660000000666w666sy