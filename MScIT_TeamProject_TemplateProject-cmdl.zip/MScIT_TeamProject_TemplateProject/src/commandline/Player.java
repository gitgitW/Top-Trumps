package commandline;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Player {
	
	private String name;
	private int cardNum;
	private Queue<Card> cards = new LinkedList<Card>();
	private Card card;
	private int isOver = 0;
	private int playerNum;
	private boolean isBot;
	private int selectedAttribute;
	
	public Player(String name, boolean isBot) {
		
		this.name = name;	
		this.isBot = isBot;
	}
	
	//METHODS
	//get player name
	public String getName() {
		return this.name;
	}
	
	//this method is the logic of AI's playing 
	public void AIPlay() {
		Random r = new Random();
		selectedAttribute = r.nextInt(5);
	}
	
	public void Play(int index) {
		selectedAttribute = index;
	}
	
	//method to select the attribute of the topmost card
	public int selectAttribute(int index) {
		return card.selectAttribute(index - 1);
	}
	 
	public void selfCheck() {
		cardNum = cards.size();
		checkOver();
	}
	public void setPlayerNum(int num) {
		playerNum = num;
	}
	public int getPlayerNum() {
		return playerNum;
	}
	
	public Queue<Card> getCards(){
		return cards;
	}
	
	public int getSelectedAttribute() {
		return selectedAttribute;
	}
	
	public Card getCard() {
		return card; 
	}
	
	public Card getTopmostCard() {
		return cards.peek();
	}
	
	public void removeTopmostCard() {
		cards.poll();
		cardNum--;
	}
	
	public void addCard(Card card) {
		cards.offer(card);
		cardNum++;
	}
	
	public int getCardNum() {
		return cardNum; 
	}
	
	public void checkOver() {
		if(this.cardNum <= 0) {
			playerOver();
		}
	}
	
	public void playerOver() {
		this.isOver = -1;
	}
	
	public int getIsOver() {
		return isOver;
	}
	
	public boolean getIsBot() {
		return isBot;
	}

}
