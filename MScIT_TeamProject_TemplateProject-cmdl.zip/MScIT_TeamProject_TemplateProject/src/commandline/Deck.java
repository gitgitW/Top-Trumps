package commandline;

import java.util.ArrayList;

public class Deck {

	protected ArrayList<Card> cards = new ArrayList<Card>();
	protected int cardNum;
	protected GameTable gt;
 	
	public Deck(GameTable gt) {
		this.gt = gt;
	}
	
	public void addCard(Card card) {
		this.cards.add(card);
		cardNum++;
		System.out.printf("Game Status: New Card Added \n");
	}
	
	
	public void dealCards() {
		int index = 0;
		while(cards.size() != 0) {
			if(index == 0) {
				gt.getPlayers()[index].addCard(cards.get(0));
			}
			else {
			gt.getPlayers()[index % gt.getPlayerNum()].addCard(cards.get(0));
			}
			cards.remove(0);
			index++;
		}
		System.out.println("Game Status: Dealed all cards from Deck");
		for(int i = 0; i < gt.getPlayers().length; i++) {
			System.out.println(gt.getPlayers()[i].getName() + ": " + gt.getPlayers()[i].getCardNum() + " Cards");
		}
	}
	
	public Card getCard(int num) {
		if(num < cardNum) {
			return cards.get(num);
		}
		else return new Card("",0,0,0,0,0);
	}
}
