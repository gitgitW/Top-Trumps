package commandline;

public class gameTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GameTable gt = new GameTable(2);
		MessageCenter mc = new MessageCenter(gt);
		Controller c = new Controller(gt,mc);
		
		Player p1 = new Player("AA",false);
		Player p2 = new Player("BB",true);
		Player p3 = new Player("CC",true);
		Player p4 = new Player("DD",true);
		Player p5 = new Player("EE",true);
		
		gt.addPlayer(p1);
		gt.addPlayer(p2);
		
		
	    AddCard ac = new AddCard("StarCitizenDeck.txt",gt.getDeck());
	    ac.addCardsFromFile();
	    gt.getDeck().dealCards();
		
		c.Play();
		
		
	}
	
	public static void play (GameTable gt) {
			//banker.selectAttribute(1);

			gt.bankerChange();
			gt.cardChange();
			gt.playerCheck();
	}

}
