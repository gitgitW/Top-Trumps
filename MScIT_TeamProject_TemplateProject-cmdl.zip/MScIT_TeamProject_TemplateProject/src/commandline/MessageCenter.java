package commandline;

public class MessageCenter {
	
	private GameTable gt;
	private Player roundWinner;
	private Card winningCard;
	public MessageCenter(GameTable gt) {
		this.gt = gt;
	}
	
	public void startInfo() {
		System.out.println("Do you want to see past results or play a game?\r\n" + 
				"   1: Print Game Statistics\r\n" + 
				"   2: Play game\r\n" + 
				"Enter the number for your selection:");
	}
	
	public void roundMassage() {
		
		Player humanPlayer = gt.getHumanPlayer();
		System.out.println("---------------------------------------------------------------\r\n" +
				"Round " + gt.getGameRound() + ": Banker: " + gt.getBanker().getName() +", Players have drawn their cards\r\n" + 
				"You drew '" + humanPlayer.getTopmostCard().getName() + "':\r\n" + 
				"   > height: " + humanPlayer.getTopmostCard().getAttributes()[0] + "\r\n" + 
				"   > weight: " + humanPlayer.getTopmostCard().getAttributes()[1] + "\r\n" + 
				"   > length: " + humanPlayer.getTopmostCard().getAttributes()[2] + "\r\n" + 
				"   > ferocity: " + humanPlayer.getTopmostCard().getAttributes()[3] + "\r\n" + 
				"   > intelligence: " + humanPlayer.getTopmostCard().getAttributes()[4] + "\r\n" + 
				"There are '" + humanPlayer.getCardNum() + "' cards in your deck");
		
		if(gt.getBanker().getIsBot() == false) {
		System.out.println("It is your turn to select a category, the categories are:\r\n" + 
				"   1: height\r\n" + 
				"   2: weight\r\n" + 
				"   3: length\r\n" + 
				"   4: ferocity\r\n" + 
				"   5: intelligence\r\n" + 
				"Enter the number for your attribute: ");
		}
		
	}
	
	public void bankerChangeMessage(boolean isChanged) {
		if(isChanged) {
			System.out.println("Player Changed: Now is : " + gt.getBanker().getName());
		}
		else {
			System.out.println("Player : " + gt.getBanker().getName() + " Continue to play.");
		}
	}
	
	public void winnerMessage(Card winningCard,Player roundWinner) {
		System.out.println(roundWinner.getName() + " won this round!\r\n" + 
	            "The winning card was: " + winningCard.getName() + "\r\n" );
		for(int i = 0; i < 5; i++) {
			System.out.print("   > " + winningCard.getAttributesName()[i] + ": " + winningCard.getAttributes()[i] );
			if (winningCard.getAttributesName()[gt.getSelectedAttribute()].equals(winningCard.getAttributesName()[i]) ) {
				System.out.println("<---");
			}
			else {
				System.out.println();
			}
		}	

	}
	
	public void selectedAttribute() {
		System.out.println(gt.getBanker().getName() + " selected: " + gt.getBanker().getTopmostCard().getSelectedAttribute(gt.getSelectedAttribute()));
	}
	
	public void livingPlayers() {
		System.out.println(gt.getLivingPlayerNum() + " Players Living...");
	}
	
	public void gameOver() {
		System.out.println("Game Over! " + gt.getRoundWinner().getName() + " is the Winner!");
	}

}
